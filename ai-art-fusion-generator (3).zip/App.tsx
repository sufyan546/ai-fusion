
import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { PromptInput } from './components/PromptInput';
import { StyleSelector } from './components/StyleSelector';
import { ImageDisplay } from './components/ImageDisplay';
import { Footer } from './components/Footer';
import { ImageUploader } from './components/ImageUploader';
import { generateImage } from './services/geminiService';
import type { ArtStyle } from './types';
import { ART_STYLES } from './constants';

const App: React.FC = () => {
  const [prompt, setPrompt] = useState<string>('A majestic fantasy castle on a floating island');
  const [selectedStyle, setSelectedStyle] = useState<ArtStyle>(ART_STYLES[0]);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [referenceImage, setReferenceImage] = useState<File | null>(null);
  const [referenceImageUrl, setReferenceImageUrl] = useState<string | null>(null);
  const [loadingMessage, setLoadingMessage] = useState<string>('Creating Magic...');

  const handleImageSelect = useCallback((file: File) => {
    // Clean up previous object URL if one exists
    if (referenceImageUrl) {
        URL.revokeObjectURL(referenceImageUrl);
    }
    setReferenceImage(file);
    setReferenceImageUrl(URL.createObjectURL(file));
  }, [referenceImageUrl]);

  const handleImageRemove = useCallback(() => {
    if (referenceImageUrl) {
        URL.revokeObjectURL(referenceImageUrl);
    }
    setReferenceImage(null);
    setReferenceImageUrl(null);
  }, [referenceImageUrl]);

  const handleGenerate = useCallback(async () => {
    if (!prompt) {
      setError('Please enter a prompt.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setGeneratedImage(null);
    setLoadingMessage('Initializing...');

    try {
      const imageUrl = await generateImage(prompt, selectedStyle, referenceImage, setLoadingMessage);
      setGeneratedImage(imageUrl);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, [prompt, selectedStyle, referenceImage]);

  return (
    <div className="min-h-screen bg-slate-900 text-slate-200 flex flex-col font-sans">
      <Header />
      <main className="flex-grow container mx-auto p-4 md:p-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
          {/* Left Column: Controls */}
          <div className="flex flex-col space-y-6">
            <PromptInput value={prompt} onChange={(e) => setPrompt(e.target.value)} disabled={isLoading} />
            <ImageUploader 
              onImageSelect={handleImageSelect}
              onImageRemove={handleImageRemove}
              previewUrl={referenceImageUrl}
              disabled={isLoading}
            />
            <StyleSelector
              styles={ART_STYLES}
              selectedStyle={selectedStyle}
              onSelectStyle={setSelectedStyle}
              disabled={isLoading}
            />
            <button
              onClick={handleGenerate}
              disabled={isLoading}
              className="w-full bg-indigo-600 text-white font-bold py-3 px-6 rounded-lg shadow-lg hover:bg-indigo-700 disabled:bg-slate-700 disabled:cursor-not-allowed transition-all duration-300 ease-in-out transform hover:scale-105 focus:outline-none focus:ring-4 focus:ring-indigo-500 focus:ring-opacity-50"
            >
              {isLoading ? 'Generating...' : 'Generate Art'}
            </button>
          </div>

          {/* Right Column: Image Display */}
          <div className="flex items-center justify-center">
            <ImageDisplay 
              isLoading={isLoading} 
              error={error} 
              image={generatedImage} 
              loadingMessage={loadingMessage}
            />
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default App;
