
import React, { useRef } from 'react';

interface ImageUploaderProps {
    onImageSelect: (file: File) => void;
    onImageRemove: () => void;
    previewUrl: string | null;
    disabled: boolean;
}

const UploadIcon: React.FC<{className?: string}> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
    </svg>
);

const CloseIcon: React.FC<{className?: string}> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
    </svg>
);

export const ImageUploader: React.FC<ImageUploaderProps> = ({ onImageSelect, onImageRemove, previewUrl, disabled }) => {
    const inputRef = useRef<HTMLInputElement>(null);

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            onImageSelect(file);
        }
    };

    const handleRemoveClick = (e: React.MouseEvent) => {
        e.stopPropagation();
        onImageRemove();
        if(inputRef.current) {
            inputRef.current.value = "";
        }
    };

    return (
        <div>
            <label className="block text-lg font-semibold mb-2 text-slate-300">
                Reference Image (Optional)
            </label>
            <div
                className={`w-full h-48 border-2 border-dashed border-slate-700 rounded-lg flex items-center justify-center text-slate-400 relative transition-colors ${!disabled && 'hover:border-indigo-500 hover:bg-slate-800/50 cursor-pointer'} ${disabled && 'opacity-50 cursor-not-allowed'}`}
                onClick={() => !disabled && inputRef.current?.click()}
                role="button"
                aria-disabled={disabled}
                tabIndex={disabled ? -1 : 0}
                onKeyDown={(e) => { if (e.key === 'Enter' && !disabled) inputRef.current?.click() }}

            >
                <input
                    type="file"
                    ref={inputRef}
                    onChange={handleFileChange}
                    accept="image/png, image/jpeg, image/webp"
                    className="hidden"
                    disabled={disabled}
                    aria-label="Upload reference image"
                />
                {previewUrl ? (
                    <>
                        <img src={previewUrl} alt="Reference preview" className="w-full h-full object-contain rounded-lg p-2" />
                        <button
                            onClick={handleRemoveClick}
                            disabled={disabled}
                            className="absolute top-2 right-2 bg-slate-900/70 rounded-full p-1.5 text-slate-300 hover:text-white hover:bg-slate-700 transition-all"
                            aria-label="Remove reference image"
                        >
                            <CloseIcon className="w-5 h-5" />
                        </button>
                    </>
                ) : (
                    <div className="text-center">
                        <UploadIcon className="w-12 h-12 mx-auto mb-2" />
                        <p>Click to upload an image</p>
                        <p className="text-xs text-slate-500 mt-1">PNG, JPG, WEBP</p>
                    </div>
                )}
            </div>
        </div>
    );
};
