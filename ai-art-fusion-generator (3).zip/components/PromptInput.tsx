
import React from 'react';

interface PromptInputProps {
  value: string;
  onChange: (event: React.ChangeEvent<HTMLTextAreaElement>) => void;
  disabled: boolean;
}

export const PromptInput: React.FC<PromptInputProps> = ({ value, onChange, disabled }) => {
  return (
    <div className="w-full">
      <label htmlFor="prompt" className="block text-lg font-semibold mb-2 text-slate-300">
        Enter Your Prompt
      </label>
      <textarea
        id="prompt"
        value={value}
        onChange={onChange}
        disabled={disabled}
        placeholder="e.g., A robot holding a red skateboard"
        rows={4}
        className="w-full p-4 bg-slate-800 border-2 border-slate-700 rounded-lg text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors duration-200 disabled:bg-slate-800/50"
      />
    </div>
  );
};
