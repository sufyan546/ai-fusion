
import React from 'react';

interface LoadingSpinnerProps {
  message?: string;
}

export const LoadingSpinner: React.FC<LoadingSpinnerProps> = ({ message = 'Creating Magic...' }) => {
  return (
    <div className="flex flex-col items-center justify-center space-y-3">
        <div className="w-16 h-16 border-4 border-t-4 border-indigo-400 border-t-transparent rounded-full animate-spin"></div>
        <p className="text-indigo-300 font-semibold">{message}</p>
        <style>{`
            @keyframes spin {
                from { transform: rotate(0deg); }
                to { transform: rotate(360deg); }
            }
            .animate-spin {
                animation: spin 1s linear infinite;
            }
        `}</style>
    </div>
  );
};
