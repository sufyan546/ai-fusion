
import React from 'react';

const PaintBrushIcon: React.FC<{className?: string}> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="currentColor">
        <path d="M13.293 3.293a1 1 0 0 1 1.414 0l4 4a1 1 0 0 1 0 1.414l-9 9a1 1 0 0 1-.39.242l-5 2a1 1 0 0 1-1.213-1.213l2-5a1 1 0 0 1 .242-.39l9-9zM14 8l-8 8-1.293 3.293 3.293-1.293L16 10l-2-2zM15 7l2-2 1.586 1.586L18 7l-3-3-1.586 1.586L13 5l2 2z"></path>
    </svg>
);


export const Header: React.FC = () => {
  return (
    <header className="bg-slate-900/70 backdrop-blur-sm sticky top-0 z-10 border-b border-slate-800">
      <div className="container mx-auto px-4 py-4 md:px-8">
        <div className="flex items-center space-x-3">
          <PaintBrushIcon className="w-8 h-8 text-indigo-400" />
          <h1 className="text-2xl md:text-3xl font-bold text-white tracking-tight">
            AI Art Fusion Generator
          </h1>
        </div>
      </div>
    </header>
  );
};
