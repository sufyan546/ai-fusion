
import React from 'react';
import type { ArtStyle } from '../types';

interface StyleSelectorProps {
  styles: ArtStyle[];
  selectedStyle: ArtStyle;
  onSelectStyle: (style: ArtStyle) => void;
  disabled: boolean;
}

export const StyleSelector: React.FC<StyleSelectorProps> = ({ styles, selectedStyle, onSelectStyle, disabled }) => {
  return (
    <div>
      <h3 className="text-lg font-semibold mb-3 text-slate-300">Choose a Style</h3>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-3 lg:grid-cols-3 gap-3">
        {styles.map((style) => (
          <button
            key={style}
            onClick={() => onSelectStyle(style)}
            disabled={disabled}
            className={`
              px-4 py-3 text-center font-semibold rounded-lg border-2 transition-all duration-200 
              ${selectedStyle === style 
                ? 'bg-indigo-600 border-indigo-500 text-white shadow-lg' 
                : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700 hover:border-slate-600'}
              disabled:opacity-50 disabled:cursor-not-allowed
            `}
          >
            {style}
          </button>
        ))}
      </div>
    </div>
  );
};
