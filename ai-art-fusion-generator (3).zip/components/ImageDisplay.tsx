
import React from 'react';
import { LoadingSpinner } from './LoadingSpinner';

interface ImageDisplayProps {
  isLoading: boolean;
  error: string | null;
  image: string | null;
  loadingMessage?: string;
}

const PlaceholderIcon: React.FC<{className?: string}> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
    </svg>
);

const DownloadIcon: React.FC<{className?: string}> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
    </svg>
);

export const ImageDisplay: React.FC<ImageDisplayProps> = ({ isLoading, error, image, loadingMessage }) => {
  return (
    <div className="w-full aspect-square bg-slate-800/50 border-2 border-dashed border-slate-700 rounded-xl flex items-center justify-center p-4 relative overflow-hidden">
      {isLoading && <LoadingSpinner message={loadingMessage} />}
      {error && !isLoading && (
        <div className="text-center text-red-400">
          <h4 className="font-bold text-lg mb-2">Generation Failed</h4>
          <p className="text-sm">{error}</p>
        </div>
      )}
      {!isLoading && !error && image && (
        <>
          <img
            src={image}
            alt="Generated Art"
            className="w-full h-full object-contain rounded-lg animate-fade-in"
          />
          <a
            href={image}
            download={`ai-art-fusion-${Date.now()}.jpeg`}
            className="absolute bottom-4 right-4 bg-indigo-600 text-white font-bold py-2 px-4 rounded-lg shadow-lg hover:bg-indigo-700 transition-all duration-300 ease-in-out flex items-center space-x-2 animate-fade-in"
            aria-label="Download Image"
          >
            <DownloadIcon className="w-5 h-5" />
            <span>Download</span>
          </a>
        </>
      )}
      {!isLoading && !error && !image && (
        <div className="text-center text-slate-500">
            <PlaceholderIcon className="w-20 h-20 mx-auto mb-4" />
            <h4 className="font-bold text-lg text-slate-400">Your artwork will appear here</h4>
            <p className="text-sm">Enter a prompt, choose a style, and click Generate.</p>
        </div>
      )}
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: scale(0.95); }
          to { opacity: 1; transform: scale(1); }
        }
        .animate-fade-in {
          animation: fadeIn 0.5s ease-in-out;
        }
      `}</style>
    </div>
  );
};
