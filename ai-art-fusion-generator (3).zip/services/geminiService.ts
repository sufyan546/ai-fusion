
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import type { ArtStyle } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const stylePrompts: Record<ArtStyle, string> = {
    'Pixel': 'in a vibrant 16-bit pixel art style, detailed sprites, retro gaming aesthetic',
    'Ghibli': 'in a beautiful ghibli anime art style, hand-drawn, whimsical, nostalgic, detailed background',
    'Pixar': 'in a 3D rendered pixar animation style, charming characters, cinematic lighting, vibrant colors',
    'Ancient': 'in the style of ancient art, like a stone carving or egyptian papyrus, historical feel',
    'Cinematic': 'in a cinematic movie style, dramatic lighting, epic scope, photorealistic details, wide angle'
};

const fileToBase64 = (file: File): Promise<string> => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve((reader.result as string).split(',')[1]); // remove data:mime/type;base64, prefix
    reader.onerror = error => reject(error);
});

const describeImage = async (file: File): Promise<string> => {
    const base64Data = await fileToBase64(file);
    const imagePart = {
      inlineData: {
        mimeType: file.type,
        data: base64Data,
      },
    };
    const textPart = {
      text: "Describe this image in detail for an AI image generator. Focus on objects, subjects, colors, and the artistic style."
    };
    
    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: { parts: [imagePart, textPart] },
        });
        return response.text;
    } catch(error) {
        console.error("Error describing image with Gemini:", error);
        throw new Error("Failed to analyze reference image.");
    }
}

export const generateImage = async (prompt: string, style: ArtStyle, referenceImageFile: File | null, setLoadingMessage: (msg: string) => void): Promise<string> => {
    let fullPrompt = `${prompt}, ${stylePrompts[style]}`;
    
    if (referenceImageFile) {
        setLoadingMessage("Analyzing reference image...");
        try {
            const description = await describeImage(referenceImageFile);
            fullPrompt = `${prompt}, visually inspired by an image described as '${description}', ${stylePrompts[style]}`;
        } catch (error) {
            // Rethrow the error to be caught by the UI
            throw error;
        }
    }

    setLoadingMessage("Generating artwork...");

    try {
        const response = await ai.models.generateImages({
            model: 'imagen-3.0-generate-002',
            prompt: fullPrompt,
            config: {
                numberOfImages: 1,
                outputMimeType: 'image/jpeg',
                aspectRatio: '1:1',
            },
        });

        if (!response.generatedImages || response.generatedImages.length === 0) {
            throw new Error("Image generation failed, no images were returned.");
        }
        
        const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
        return `data:image/jpeg;base64,${base64ImageBytes}`;

    } catch (error) {
        console.error("Error generating image with Gemini:", error);
        if (error instanceof Error) {
            // Avoid nesting "Failed to generate image"
            if(error.message.startsWith("Failed to")) {
                throw error;
            }
            throw new Error(`Failed to generate image: ${error.message}`);
        }
        throw new Error("An unknown error occurred during image generation.");
    }
};
