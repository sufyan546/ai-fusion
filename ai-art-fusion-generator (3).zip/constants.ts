
import type { ArtStyle } from './types';

export const ART_STYLES: ArtStyle[] = ['Pixel', 'Ghibli', 'Pixar', 'Ancient', 'Cinematic'];
