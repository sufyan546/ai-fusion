
export type ArtStyle = 'Pixel' | 'Ghibli' | 'Pixar' | 'Ancient' | 'Cinematic';
